angular
    .module('user', []);
