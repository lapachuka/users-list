angular
    .module('app', [
        'ui.router',
        'ngAnimate',
        'ngMaterial',
        'templates-main', // we are using angularjs template cache
        'user'
    ]);